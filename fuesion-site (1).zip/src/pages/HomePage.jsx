import React, { useState } from "react";

const HomePage = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    datetime: "",
    message: ""
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    alert("Appointment request submitted (mock).");
  };

  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>FUEsion Aesthetics</h1>
      <p>Hair & Body Restoration Medical Spa – Combining Science, Art & Confidence</p>
      <form onSubmit={handleSubmit}>
        <input name="name" placeholder="Full Name" onChange={handleChange} /><br />
        <input name="email" placeholder="Email Address" onChange={handleChange} /><br />
        <input name="phone" placeholder="Phone Number" onChange={handleChange} /><br />
        <input name="datetime" placeholder="Preferred Date & Time" onChange={handleChange} /><br />
        <textarea name="message" placeholder="Message" onChange={handleChange}></textarea><br />
        <button type="submit">Request Appointment</button>
      </form>
    </div>
  );
};

export default HomePage;
